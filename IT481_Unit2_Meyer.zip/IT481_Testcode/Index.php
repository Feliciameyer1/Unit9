<html>
<head>
<meta charset="ISO-8859-1">
<title>Employees</title>

</head>
<body>
<header>
<h1>Welcome</h1>
</header>
<nav>
<a href="EmployeeMenuCodes/Employees.php">Employee Menu</a>
<a href="Customers/Customers.php">Customer Menu</a>
<a href="Products/Products.php">Products Menu</a>
</nav>
<p>Welcome to IT481 Web application. Click on the links to get started.</p>

</body>
</html>
